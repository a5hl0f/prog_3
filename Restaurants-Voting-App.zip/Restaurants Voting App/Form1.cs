﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restaurants_Voting_App
{
    public partial class Form1 : Form
    {
        private List<Restaurant> restaurants = new List<Restaurant>();

        public Form1()
        {
            InitializeComponent();
            this.CenterToScreen();
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.FileName = "restaurants.txt";
            saveFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            saveFileDialog1.FileName = "result.txt";
            votingMenuItem.Enabled = false;
            resultMenuItem.Enabled = false;
        }

        private void openMenuItem_Click(object sender, EventArgs e)
        {

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader streamReader = null;
                try
                {

                    string fileName = openFileDialog1.FileName;
                    streamReader = new StreamReader(fileName);
                    Input(streamReader);

                    openMenuItem.Enabled = false;
                    votingMenuItem.Enabled = true;

                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);

                }
                finally
                {

                    if (streamReader != null)
                    {
                        streamReader.Close();
                    }

                }

            }

        }

        private void Input(StreamReader streamReader)
        {

            string line;
            string[] data;
            while (!streamReader.EndOfStream)
            {
                line = streamReader.ReadLine();
                data = line.Split(';');
                restaurants.Add(new Restaurant(data[0], data[1]));
            }



        }

        private void exitMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void authorMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello world", "hello world");
        }

        private void votingMenuItem_Click(object sender, EventArgs e)
        {
            VotingForm votingForm = new VotingForm();
            votingForm.CreateLayout(restaurants);
            votingForm.ShowDialog();
            votingMenuItem.Enabled = false;
            resultMenuItem.Enabled = true;
        }

        private void resultMenuItem_Click(object sender, EventArgs e)
        {
            ResultForm resultForm = new ResultForm();
            resultForm.DisplayResults(restaurants);
            resultForm.ShowDialog();
        }

        private void saveMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {

                StreamWriter streamWriter = null;
                try
                {

                    streamWriter = new StreamWriter(saveFileDialog1.FileName);
                    foreach (Restaurant item in restaurants)
                    {

                        streamWriter.WriteLine(item.Name + ";" + item.Address + ";" + item.NumberOfVotes);

                    }

                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);

                }
                finally
                {

                    if (streamWriter != null)
                    {
                        streamWriter.Close();
                    }

                }

            }
        }
    }
}
