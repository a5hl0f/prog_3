﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restaurants_Voting_App
{
    public partial class ResultForm : Form
    {

        private List<Restaurant> restaurants = new List<Restaurant>();
        public ResultForm()
        {
            InitializeComponent();
        }

        internal void DisplayResults(List<Restaurant> restaurants)
        {

            this.restaurants = restaurants;
            foreach (Restaurant item in restaurants)
            {
                lstBoxResult.Items.Add(item);
            }

            
        }


    }
}
