﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restaurants_Voting_App
{
    public partial class VotingForm : Form
    {

        private List<Restaurant> restaurants = new List<Restaurant>();
        private List<PictureBox> pictureBoxes = new List<PictureBox>();
        private List<Label> labels = new List<Label>();
        private List<RadioButton> radioButtons = new List<RadioButton>();

        //Controls
         int imgWidth = 200, imgHeight = 100, dist = 10, rdbDistX = 20;



        public VotingForm()
        {
            InitializeComponent();
        }

        private void btnRating_Click(object sender, EventArgs e)
        {
            bool ChooseOrNot = false;
            for (int i = 0; i < restaurants.Count; i++)
            {

                if (radioButtons[i].Checked)
                {

                    restaurants[i].ReceiveVote();
                    ChooseOrNot = true;
                    radioButtons[i].Checked = false;
                    break;

                }

            }

            if (!ChooseOrNot)
            {
                MessageBox.Show("Please Select a Restaurant", "Error");
            }
        }

        internal void CreateLayout(List<Restaurant> restaurants)
        {

            PictureBox pictureBox;
            Label label;
            RadioButton radioButton;
            this.restaurants = restaurants;

            for (int i = 0; i < restaurants.Count; i++)
            {

                //Picturebox
                pictureBox = new PictureBox();
                pictureBox.Location = new Point(dist, dist + i * (imgHeight + dist));
                pictureBox.Size = new Size(imgWidth, imgHeight);
                pictureBox.Image = Image.FromFile(restaurants[i].Name + ".jpg");
                pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;

                pnlControls.Controls.Add(pictureBox);
                pictureBoxes.Add(pictureBox);

                //TextBox
                label = new Label();
                label.AutoSize = true;
                label.Location = new Point(imgWidth + 2 * dist, pictureBox.Location.Y + imgHeight / 2);
                label.Text = restaurants[i].Name + "     " +restaurants[i].Address;

                pnlControls.Controls.Add(label);
                labels.Add(label);

                //RadioButton
                radioButton = new RadioButton();
                radioButton.AutoSize = true;
                radioButton.Location = new Point(imgWidth * 2 + dist + rdbDistX, pictureBox.Location.Y + imgHeight / 2);

                pnlControls.Controls.Add(radioButton);
                radioButtons.Add(radioButton);

            }

        }
    }
}
