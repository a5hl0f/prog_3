﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurants_Voting_App
{
    class Restaurant
    {
        public string Name { get; private set; }
        public string Address { get; private set; }
        public int NumberOfVotes { get; set; }

        public Restaurant(string name, string address)
        {
            this.Name = name;
            this.Address = address;
        }

        public void ReceiveVote()
        {
            NumberOfVotes++;
        }

        public override string ToString()
        {
            return Name +  NumberOfVotes.ToString().PadRight(80);
        }

    }
}
