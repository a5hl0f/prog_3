﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PubBar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            saveFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.FileName = "drink_menu.txt";
            saveFileDialog1.FileName = "booking.txt";

        }
        private List<Drink> drink = new List<Drink>();
        private List<Image> pictures = new List<Image>();
        private void openToolStripMenu(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader streamreader = null;
                try
                {
                    string filename = openFileDialog1.FileName;
                    streamreader = new StreamReader(filename);
                    Input(streamreader);
                    drinkMenuToolStripMenuItem.Enabled = true;
                    saveToolStripMenuItem.Enabled = true;
                }
                catch(Exception EX)
                {
                    MessageBox.Show(EX.Message, "error");

                }
                finally
                {
                    if (streamreader != null)
                    {
                        streamreader.Close();
                    }
                }
            }
        }

        private void Input(StreamReader streamreader)
        {
            string line;
            string[] data;
            while (!streamreader.EndOfStream)
            {
                line = streamreader.ReadLine();
                data = line.Split(';');
                drink.Add(new Drink(data[0], int.Parse(data[1])));
            }
        }

        private void drinkMenuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DrinkMenuForm drinkmenuforrm = new DrinkMenuForm();
            drinkmenuforrm.WriteDrinkMenu(drink);
            drinkmenuforrm.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog()==DialogResult.OK)
            {
                StreamWriter write = null;
                try
                {
                    string fileNmae = saveFileDialog1.FileName;
                    write = new StreamWriter(fileNmae);
                    WriteToFile(write);
                }
                catch
                {
                    MessageBox.Show("error with file writing ...");
                }
                finally
                {
                    if (write != null)
                    {
                        write.Close();
                    }
                }
            }
        }

        private void WriteToFile(StreamWriter write)
        {
            foreach(Drink item in drink)
            {
                write.WriteLine(item.ToBooking());
            }
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            HelpForm helpform = new HelpForm();
           helpform.help.Text = helpform.writehelp();
            /*helpform.writehelp();*/
            helpform.ShowDialog();
        }

        private void galleryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GalleryForm galleryform = new GalleryForm();
            galleryform.ShowDialog();
        }

     
    }
}
// main form 
/*
  private List<Restaurant> restaurants = new List<Restaurant>();

        public Form1()
        {
            InitializeComponent();
            this.CenterToScreen();
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.FileName = "restaurants.txt";
            saveFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            saveFileDialog1.FileName = "result.txt";
            votingMenuItem.Enabled = false;
            resultMenuItem.Enabled = false;
        }

        private void openMenuItem_Click(object sender, EventArgs e)
        {

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader streamReader = null;
                try
                {

                    string fileName = openFileDialog1.FileName;
                    streamReader = new StreamReader(fileName);
                    Input(streamReader);

                    openMenuItem.Enabled = false;
                    votingMenuItem.Enabled = true;

                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);

                }
                finally
                {

                    if (streamReader != null)
                    {
                        streamReader.Close();
                    }

                }

            }

        }

        private void Input(StreamReader streamReader)
        {

            string line;
            string[] data;
            while (!streamReader.EndOfStream)
            {
                line = streamReader.ReadLine();
                data = line.Split(';');
                restaurants.Add(new Restaurant(data[0], data[1]));
            }



        }

        private void exitMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void authorMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello world", "hello world");
        }

        private void votingMenuItem_Click(object sender, EventArgs e)
        {
            VotingForm votingForm = new VotingForm();
            votingForm.CreateLayout(restaurants);
            votingForm.ShowDialog();
            votingMenuItem.Enabled = false;
            resultMenuItem.Enabled = true;
        }

        private void resultMenuItem_Click(object sender, EventArgs e)
        {
            ResultForm resultForm = new ResultForm();
            resultForm.DisplayResults(restaurants);
            resultForm.ShowDialog();
        }

        private void saveMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {

                StreamWriter streamWriter = null;
                try
                {

                    streamWriter = new StreamWriter(saveFileDialog1.FileName);
                    foreach (Restaurant item in restaurants)
                    {

                        streamWriter.WriteLine(item.Name + ";" + item.Address + ";" + item.NumberOfVotes);

                    }

                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);

                }
                finally
                {

                    if (streamWriter != null)
                    {
                        streamWriter.Close();
                    }

                }

            }
        }
*/
/*
 * resturant class
  class Restaurant
    {
        public string Name { get; private set; }
        public string Address { get; private set; }
        public int NumberOfVotes { get; set; }

        public Restaurant(string name, string address)
        {
            this.Name = name;
            this.Address = address;
        }

        public void ReceiveVote()
        {
            NumberOfVotes++;
        }

        public override string ToString()
        {
            return Name +  NumberOfVotes.ToString().PadRight(80);
        }

    }
 */
/*
 * result from
 public partial class ResultForm : Form
    {

        private List<Restaurant> restaurants = new List<Restaurant>();
        public ResultForm()
        {
            InitializeComponent();
        }

        internal void DisplayResults(List<Restaurant> restaurants)
        {

            this.restaurants = restaurants;
            foreach (Restaurant item in restaurants)
            {
                lstBoxResult.Items.Add(item);
            }

            
        }


    }
 */
// voting form
/*
 *  public partial class VotingForm : Form
    {

        private List<Restaurant> restaurants = new List<Restaurant>();
        private List<PictureBox> pictureBoxes = new List<PictureBox>();
        private List<Label> labels = new List<Label>();
        private List<RadioButton> radioButtons = new List<RadioButton>();

        //Controls
         int imgWidth = 200, imgHeight = 100, dist = 10, rdbDistX = 20;



        public VotingForm()
        {
            InitializeComponent();
        }

        private void btnRating_Click(object sender, EventArgs e)
        {
            bool ChooseOrNot = false;
            for (int i = 0; i < restaurants.Count; i++)
            {

                if (radioButtons[i].Checked)
                {

                    restaurants[i].ReceiveVote();
                    ChooseOrNot = true;
                    radioButtons[i].Checked = false;
                    break;

                }

            }

            if (!ChooseOrNot)
            {
                MessageBox.Show("Please Select a Restaurant", "Error");
            }
        }

        internal void CreateLayout(List<Restaurant> restaurants)
        {

            PictureBox pictureBox;
            Label label;
            RadioButton radioButton;
            this.restaurants = restaurants;

            for (int i = 0; i < restaurants.Count; i++)
            {

                //Picturebox
                pictureBox = new PictureBox();
                pictureBox.Location = new Point(dist, dist + i * (imgHeight + dist));
                pictureBox.Size = new Size(imgWidth, imgHeight);
                pictureBox.Image = Image.FromFile(restaurants[i].Name + ".jpg");
                pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;

                pnlControls.Controls.Add(pictureBox);
                pictureBoxes.Add(pictureBox);

                //TextBox
                label = new Label();
                label.AutoSize = true;
                label.Location = new Point(imgWidth + 2 * dist, pictureBox.Location.Y + imgHeight / 2);
                label.Text = restaurants[i].Name + "     " +restaurants[i].Address;

                pnlControls.Controls.Add(label);
                labels.Add(label);

                //RadioButton
                radioButton = new RadioButton();
                radioButton.AutoSize = true;
                radioButton.Location = new Point(imgWidth * 2 + dist + rdbDistX, pictureBox.Location.Y + imgHeight / 2);

                pnlControls.Controls.Add(radioButton);
                radioButtons.Add(radioButton);

            }

        }
    }
*/