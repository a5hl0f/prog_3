﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PubBar
{
    public partial class GalleryForm : Form
    {
        public GalleryForm()
        {
            InitializeComponent();
        }

        private void right_Click(object sender, EventArgs e)
        {
            
            if (pictureBox1.Visible == true)
            {
                pictureBox3.Visible = true;
                pictureBox4.Visible = false;
                pictureBox5.Visible = false;
                pictureBox1.Visible = false;
            }
            else if(pictureBox3.Visible == true)
            {
                pictureBox4.Visible = true;
                pictureBox5.Visible = false;
                pictureBox1.Visible = false;
                pictureBox3.Visible = false;
            }
            else if (pictureBox4.Visible == true)
            {
                pictureBox5.Visible = true;
                pictureBox4.Visible = false;
                pictureBox3.Visible = false;
                pictureBox1.Visible = false;
            }
            else if (pictureBox4.Visible == true)
            {
                pictureBox5.Visible = true;
                pictureBox4.Visible = false;
                pictureBox3.Visible = false;
                pictureBox1.Visible = false;
            }
            else if (pictureBox5.Visible == true)
            {
                pictureBox1.Visible = true;
                pictureBox3.Visible = false;
                pictureBox4.Visible = false;
                pictureBox4.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Visible == true)
            {
                pictureBox3.Visible = true;
                pictureBox4.Visible = false;
                pictureBox5.Visible = false;
                pictureBox1.Visible = false;
            }
            else if (pictureBox3.Visible == true)
            {
                pictureBox4.Visible = true;
                pictureBox5.Visible = false;
                pictureBox1.Visible = false;
                pictureBox3.Visible = false;
            }
            else if (pictureBox4.Visible == true)
            {
                pictureBox5.Visible = true;
                pictureBox4.Visible = false;
                pictureBox3.Visible = false;
                pictureBox1.Visible = false;
            }
            else if (pictureBox4.Visible == true)
            {
                pictureBox5.Visible = true;
                pictureBox4.Visible = false;
                pictureBox3.Visible = false;
                pictureBox1.Visible = false;
            }
            else if (pictureBox5.Visible == true)
            {
                pictureBox1.Visible = true;
                pictureBox3.Visible = false;
                pictureBox4.Visible = false;
                pictureBox4.Visible = false;
            }
        }
    }
}
