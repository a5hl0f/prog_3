﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PubBar
{
    public partial class BillForm : Form
    {
        public BillForm()
        {
            InitializeComponent();
        }

        private void BillForm_Load(object sender, EventArgs e)
        {

        }

        internal void FillTHEriCHTXTBOX(List<Drink> drink)
        {
            rchtctbox.Clear();
            foreach(Drink item in drink)
            {
                if (item.OrderQuantity != 0)
                {
                    rchtctbox.Text += item.ToString() +"\n";
                }
            }
        }

        
    }
}
