﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PubBar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            saveFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.FileName = "drink_menu.txt";
            saveFileDialog1.FileName = "booking.txt";

        }
        private List<Drink> drink = new List<Drink>();
        private List<Image> pictures = new List<Image>();
        private void openToolStripMenu(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader streamreader = null;
                try
                {
                    string filename = openFileDialog1.FileName;
                    streamreader = new StreamReader(filename);
                    Input(streamreader);
                    drinkMenuToolStripMenuItem.Enabled = true;
                    saveToolStripMenuItem.Enabled = true;
                }
                catch(Exception EX)
                {
                    MessageBox.Show(EX.Message, "error");

                }
                finally
                {
                    if (streamreader != null)
                    {
                        streamreader.Close();
                    }
                }
            }
        }

        private void Input(StreamReader streamreader)
        {
            string line;
            string[] data;
            while (!streamreader.EndOfStream)
            {
                line = streamreader.ReadLine();
                data = line.Split(';');
                drink.Add(new Drink(data[0], int.Parse(data[1])));
            }
        }

        private void drinkMenuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DrinkMenuForm drinkmenuforrm = new DrinkMenuForm();
            drinkmenuforrm.WriteDrinkMenu(drink);
            drinkmenuforrm.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog()==DialogResult.OK)
            {
                StreamWriter write = null;
                try
                {
                    string fileNmae = saveFileDialog1.FileName;
                    write = new StreamWriter(fileNmae);
                    WriteToFile(write);
                }
                catch
                {
                    MessageBox.Show("error with file writing ...");
                }
                finally
                {
                    if (write != null)
                    {
                        write.Close();
                    }
                }
            }
        }

        private void WriteToFile(StreamWriter write)
        {
            foreach(Drink item in drink)
            {
                write.WriteLine(item.ToBooking());
            }
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            HelpForm helpform = new HelpForm();
           helpform.help.Text = helpform.writehelp();
            /*helpform.writehelp();*/
            helpform.ShowDialog();
        }

        private void galleryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GalleryForm galleryform = new GalleryForm();
            galleryform.ShowDialog();
        }

     
    }
}
