﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PubBar
{
    public partial class DrinkMenuForm : Form
    {
        public DrinkMenuForm()
        {
            InitializeComponent();
        }
        private List<Drink> drink = new List<Drink>();
        private List<CheckBox> checkBoxes = new List<CheckBox>();
        private List<TextBox> txtbox = new List<TextBox>();
        private int left = 10, top = 10, chxsize = 250, chydistance = 40, txtxsize = 30, txtysize = 17, txtboxlbldistance = 5;

        private void payToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            foreach (Drink item in drink)
            {
                item.Pay();
            }
        }

        private void billToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            BillForm bilfor = new BillForm();
            bilfor.FillTHEriCHTXTBOX(drink);
            bilfor.ShowDialog();
        }

       

      

        private int maxquantity = 999;
        private void button1_Click(object sender, EventArgs e)
        {
            int ordpieces = 0;
            bool selected = false;
            bool wrongpices = false;
            for(int i = 0; i < checkBoxes.Count; i++)
            {
                if (checkBoxes[i].Checked) {
                    selected = true;
                    try
                    {
                        ordpieces = int.Parse(txtbox[i].Text);
                        if (ordpieces <= 0 || ordpieces>maxquantity)throw new Exception();

                         drink[i].Order(ordpieces);
                        txtbox[i].BackColor = Color.White;
                        checkBoxes[i].Checked = false;
                        txtbox[i].Clear();
                    }
                    catch
                    {
                        txtbox[i].BackColor = Color.Red;
                        wrongpices = true;
                    }
                  }
                if (!selected)
                {
                    MessageBox.Show("you have to select to some thing");
                }else if (wrongpices)
                {
                    MessageBox.Show("there is problem with the red ");
                }
            }
        }

      

        

        internal void WriteDrinkMenu(List<Drink> drink)
        {
            panel1.Controls.Clear();
            checkBoxes.Clear();
            txtbox.Clear();
            this.drink = drink;



            CheckBox chkBox;
            TextBox txtBox;
            Label lbl;
            for(int i = 0; i < drink.Count; i++)
            {
                //chkbox
                chkBox = new CheckBox();
                chkBox.Text = drink[i].ToPriceList();
                chkBox.Size = new Size(chxsize, txtysize);
                chkBox.Location = new Point(left, top + i * chydistance);
                //txtbox
                txtBox = new TextBox();
                txtBox.Size = new Size(txtxsize, txtysize);
                txtBox.Location = new Point(left + chxsize, chkBox.Location.Y);
                //label
                lbl = new Label();
                lbl.Text = "piece";
                lbl.Location = new Point(txtBox.Location.X+txtxsize);


                panel1.Controls.Add(chkBox);
                panel1.Controls.Add(txtBox);
                panel1.Controls.Add(lbl);


                checkBoxes.Add(chkBox);
                txtbox.Add(txtBox);
                

            }
        }

        
    }
}
