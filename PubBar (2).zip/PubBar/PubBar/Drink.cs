﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PubBar
{
    class Drink
    {
        public string DrinName { get; private set; }
        public int UnitPrice { get; set; }
        public int OrderQuantity { get; set; }
        public int TotalQuantity { get; set; }
        public int Income { get; set; }
        public Drink(string drinkname, int unitprice)
        {
            this.DrinName = drinkname;
            this.UnitPrice = unitprice;
        }
        public void Order(int piece)
        {
            OrderQuantity += piece;
        }
        public int Payable()
        {
            return OrderQuantity * UnitPrice;
        }public void Pay()
        {
            TotalQuantity += OrderQuantity;
            Income += Payable();
            OrderQuantity = 0;
        }public string ToPriceList()
        {
            return DrinName + "(" + UnitPrice + ")";
        }
        public string ToBooking()
        {
            return DrinName + ";" + TotalQuantity + ";" + Income;
        }
        public override string ToString()
        {
            return OrderQuantity.ToString() + " " + 
                DrinName + Payable().ToString() + "ft";
        }
    }
}
