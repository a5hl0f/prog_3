﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PubBar
{
    public partial class HelpForm : Form
    {
        public HelpForm()
        {
            InitializeComponent();
        }

       

        internal string writehelp()
        {
         return     "A pub (short for public house) is an establishment licensed to " +
              "serve alcoholic drinks for consumption on the premises. The term public house " +
              "first appeared in the late 17th century, and was used to differentiate private houses" +
              " from those which were, quite literally, open to the public as 'alehouses', 'taverns'" +
              " and 'inns'. By Georgian times it had become common parlance, although taverns, as a " +
              "distinct establishment, had largely ceased to exist by the beginning of the 19th " +
              "century.[1] Today, pubs have no strict definition," +
              " but CAMRA states a pub has four characteristics:[2]";
        }
    }
}
