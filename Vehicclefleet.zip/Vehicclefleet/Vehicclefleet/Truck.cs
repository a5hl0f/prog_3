﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicclefleet
{
    class Truck:Vehicle
    {
        public double CarryingCapacity{ get;private set; }
        public static double Multiplier { get; set; }

        public Truck(string id, string registrantionnumber,
            int manufactureyear, double fuelconsumption, double carringCapacity
            ) : base(id, registrantionnumber, manufactureyear, fuelconsumption)
        {
            this.CarryingCapacity = carringCapacity;
        }
        public override int RentFee()
        {
            return (int)(base.RentFee() + CarryingCapacity * Multiplier);

        }

    }
    
}
