﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicclefleet
{
    class Bus:Vehicle
    {
        public int Seats { get;private set; }
        public  static double Multplier { get; set; }
        public Bus(string id, string registrationnumber,int manufactureyear, double consumptuion, int seats) : base(id, registrationnumber, manufactureyear)
        {
            this.Seats = seats;
        }
        public override int RentFee()
        {
            return (int)(base.RentFee() + Seats * Multplier);
        }
    }
}
