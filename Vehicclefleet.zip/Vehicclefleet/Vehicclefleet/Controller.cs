﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Vehicclefleet
{
    internal class Controller
    {
        public Controller()
        {
        }
        private List<Vehicle> vehicle = new List<Vehicle>();
        private string BUS = "bus";
        private string TRUCK = "truck ";

        internal void Start()
        {
            SetUpStatics();
            Registration();
            Output();
            Renting();
            Output();
            Statistics();// average() ,maxtravel()
            Sorting();
        }

        private void Sorting()
        {
            throw new NotImplementedException();
        }

        private void Statistics()
        {
            throw new NotImplementedException();
        }

        private void Renting()
        {
            throw new NotImplementedException();
        }

        private void Output()
        {
            Console.WriteLine("\n outpuit: \n");
            foreach(Vehicle item in vehicle)
            {
                Console.WriteLine(item);
            }
        }

        private void Registration()
        {
            string type, regnum, id;
            int manyear, seats;
            double consumptuion, carrcap;
            // TXT :
            int idnumber=1;
            string dataline;
            string[] data;
            StreamReader reader = new StreamReader("vehicle.txt");
            try
            {
                while (!reader.EndOfStream)
                {
                    dataline = reader.ReadLine();
                    data = dataline.Split(';');
                    type = data[0];
                    regnum = data[1];
                    manyear = int.Parse(data[2]);
                    consumptuion = double.Parse(data[3]);
                    id = type.Substring(0, 1).ToLower() + idnumber;

                    if(type==BUS)
                    {
                        seats = int.Parse(data[4]);
                        vehicle.Add(new Bus(id, regnum, manyear, consumptuion, seats));

                    
                    
                    }else if(type == TRUCK)
                    {
                        carrcap = double.Parse(data[4]);
                        vehicle.Add(new Truck(id, regnum, manyear, consumptuion, carrcap));
                    }
                    idnumber++;

                }
                reader.Close();
            }
            catch (Exception EX)
            {
                Console.WriteLine(EX);
            }
        }

        private void SetUpStatics()
        {
            Vehicle.BaseFee = 100;
            Vehicle.CurrentYear = 2021;
            Vehicle.ProfitMargin = 10;
            Bus.Multplier = 15;
            Truck.Multiplier = 8.5;
        }
    }
}