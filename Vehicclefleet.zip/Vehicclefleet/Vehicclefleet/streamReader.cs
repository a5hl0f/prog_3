﻿namespace Vehicclefleet
{
    internal class streamReader
    {
    }
}