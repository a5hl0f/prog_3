﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicclefleet
{
    abstract class Vehicle
    {
        public string id{ get;private set; }
        public string RegistrationNumber { get; private set; }
        public int ManufactureYear { get;private set; }
        public double FuelConsumption { get; set; }
        public double TraveledKM { get;private set; }
        public bool IsFree{ get; set; }
        public int CurentCost{ get;private set; }
        public static  int BaseFee { get; set; }
        public static int CurrentYear { get; set; }
        public  static int ProfitMargin { get; set; }
        //const.
        public Vehicle(string id ,string registrationNnumber,int manufactureyear,double fuelconssumption)
        {
            this.id = id;
            this.RegistrationNumber = registrationNnumber;
            this.ManufactureYear = manufactureyear;
            this.FuelConsumption = fuelconssumption;
            this.IsFree = true;

        }
        public Vehicle(string id, string registrationNnumber, int manufactureyear)
        {
            this.id = id;
            this.RegistrationNumber = registrationNnumber;
            this.ManufactureYear = manufactureyear;
            
            this.IsFree = true;

        }
        public int Age()
        {
            return CurrentYear - ManufactureYear;

        }
        public bool Transport(double currentdistance,int fuelprice)
        {
            if (IsFree)
            {
                TraveledKM += currentdistance;
                CurentCost=(int)(fuelprice*currentdistance*FuelConsumption/100);
                IsFree = false;
                return true;
            }
            return false;
        }
        public virtual int RentFee()
        {
            return (int)(BaseFee + CurentCost + CurentCost * ProfitMargin / 100);
        }
        public void TransportEnd()
        {
            IsFree = true;
        }
        public override string ToString()
        {
            string name = this.GetType().Name.ToLower();
            return string.Format("\n the id of {0,-5}:{1,3}"+"\n Registration number ...."+
                "\n age ......"+ 
                "\n fuelconsumption ....."+
                name,id,RegistrationNumber,Age(),FuelConsumption);
            // HW.......

        }
    }
}
